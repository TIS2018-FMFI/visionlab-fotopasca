import numpy as np
import cv2
from tkinter import *

#####

class Config:
    def __init__(self):
        self.root = Tk()
        self.root.title("Config")
        self.root.resizable(0,0)
        self.root.config(background="gray")
        self.root.option_add("*Font", "courier 14")
        self.root.attributes("-topmost", True)
        self.setupOptions()

    def setupOptions(self):
        self.resolutionOption()
        self.framerateOption()
        self.recordOption()
        self.timelapseOption()
        self.alarmOption()
        self.skipOption()
        self.saveOption()
        self.showOption()

    def resolutionOption(self):
        self.resVar = StringVar(self.root)
        self.resVar.set("1280x960") #default value
        self.resolution = OptionMenu(self.root, self.resVar, "1280x960", "800x600", "640x480")
        self.resolution.grid(row=0, columnspan=4, padx=(10,10), pady=(10,10))

    def framerateOption(self):
        self.framerate = Scale(self.root, from_=10, to=90, orient=HORIZONTAL, resolution=10)
        self.framerate.grid(row=1, columnspan=4, padx=(10,10), pady=(10,10))

    def recordOption(self):
        self.recVar = IntVar()
        self.record = Checkbutton(self.root, text="nahrávanie", variable=self.recVar)
        self.record.grid(row=2, column=0, padx=(10,10), pady=(10,10))

    def timelapseOption(self):
        self.timelapseVar = IntVar()
        self.timelapse = Checkbutton(self.root, text="časozber", variable=self.timelapseVar)
        self.timelapse.grid(row=2, column=1, padx=(10,10), pady=(10,10))

    def alarmOption(self):
        self.alarmVar = IntVar()
        self.alarm = Checkbutton(self.root, text="alarm", variable=self.alarmVar)
        self.alarm.grid(row=2, column=2, padx=(10,10), pady=(10,10))

    def skipOption(self):
        self.skipVar = IntVar()
        self.skip = Checkbutton(self.root, text="preskoč", variable=self.skipVar)
        self.skip.grid(row=2, column=3, padx=(10,10), pady=(10,10))

    def saveOption(self, c = lambda:print("Click...")):
        self.save = Button(self.root,text="ulož nastavenia",height=2,width=20,command=c,bg="white")
        self.save.grid(row=3, column=2, columnspan=2, padx=(10,10), pady=(10,10))

    def showOption(self):
        def zobraz():
            print("----------NASTAVENIA----------")
            print("rozlíšenie: " + str(self.resVar.get()))
            print("snímkovanie: " + str(self.framerate.get()))
            print("nahrávanie: " + str(self.recVar.get()))
            print("časozber: " + str(self.timelapseVar.get()))
            print("alarm: " + str(self.alarmVar.get()))
            print("preskoč konfiguráciu: " + str(self.skipVar.get()))
            print("------------------------------")
        self.show = Button(self.root,text="zobraz nastavenia",height=2,width=20,command=zobraz,bg="white")
        self.show.grid(row=3, column=0, columnspan=2, padx=(10,10), pady=(10,10))

    def returnSettings(self):
        s = Settings()
        s.resolution = tuple((int(val) for val in self.resVar.get().split('x')))
        s.framerate = int(self.framerate.get())
        s.timelapse = bool(self.timelapseVar.get())
        return s

#####
        
class Runtime:
    recUpX = -1
    recUpY = -1
    recDownX = -1
    recDownY = -1
    
    def __init__(self, s, c = lambda:print("Click...")):
        self.settings = s
        cv2.namedWindow('Runtime')
        ###Camera OR Video
        self.cap = cv2.VideoCapture(0)
        ret, self.root = self.cap.read()
        ret = False
        if (ret == True):
            self.camera = True
        else:
            self.cap = cv2.VideoCapture('video.mp4')
            ret, self.root = self.cap.read()
            self.camera = False
            self.frameCounter = 0
        ###
        self.width, self.height = self.settings.resolution
        self.drawing = False
        self.button = False
        self.mouseEvent(c)
        self.run = True
        while(self.run):
            if self.camera == False:
                self.frameCounter += 1
                if self.frameCounter > 130:
                    self.frameCounter = 0
                    self.cap.release()
                    self.cap = cv2.VideoCapture('video.mp4')
            ret, self.root = self.cap.read()
            self.prepareFrame()
            cv2.imshow('Runtime', self.root)
            if cv2.waitKey(80) & 0xFF == ord('q'): #wait for 'q' to be pressed
                break
        self.cap.release()
        cv2.destroyAllWindows()

    def prepareFrame(self):
        self.root = cv2.resize(self.root, self.settings.resolution)
        self.root = cv2.cvtColor(self.root, cv2.COLOR_BGR2GRAY)
        self.root = cv2.cvtColor(self.root, cv2.COLOR_GRAY2BGR)
        self.showUi()
        self.configButton()
        if (self.recUpX != self.recDownX and self.recUpY != self.recDownY):
            cv2.rectangle(self.root,(self.recUpX, self.recUpY),(self.recDownX, self.recDownY),(0,255,0),3) 

    def showUi(self):
        cv2.rectangle(self.root,(0, self.height-80),(self.width, self.height),(50,50,50),-1) #bar
        if self.settings.timelapse == True:
            cv2.putText(self.root,'Timelapse is activated...',(20,self.height-45), cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,255,255),1,cv2.LINE_AA) #info text
        else:
            cv2.putText(self.root,'Timelapse is deactivated...',(20,self.height-45), cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,255,255),1,cv2.LINE_AA) #info text
            
        cv2.putText(self.root,'Terminate the app with Q',(20,self.height-25), cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,255,255),1,cv2.LINE_AA) #info text

             
            
    def configButton(self):
        UP_X, UP_Y, DOWN_X, DOWN_Y = self.buttonCoordinates()
        
        if self.button:
            cv2.rectangle(self.root,(UP_X, UP_Y),(DOWN_X , DOWN_Y),(255,255,255),-1)
            cv2.rectangle(self.root,(UP_X, UP_Y),(DOWN_X , DOWN_Y),(0,0,0),2)
            cv2.putText(self.root,'Config',(UP_X + 25,UP_Y + 27), cv2.FONT_HERSHEY_SIMPLEX,0.8,(0,0,0),1,cv2.LINE_AA)
        else:
            cv2.rectangle(self.root,(UP_X, UP_Y),(DOWN_X , DOWN_Y),(0,0,0),-1)
            cv2.rectangle(self.root,(UP_X, UP_Y),(DOWN_X , DOWN_Y),(255,255,255),2)
            cv2.putText(self.root,'Config',(UP_X + 25,UP_Y + 27), cv2.FONT_HERSHEY_SIMPLEX,0.8,(255,255,255),1,cv2.LINE_AA)

    def buttonCoordinates(self):
        return self.width - 150, self.height - 60, self.width - 20, self.height - 20
        
    def mouseEvent(self, c):
        def event(event,x,y,flags,param):
            UP_X, UP_Y, DOWN_X, DOWN_Y = self.buttonCoordinates()
            
            if event == cv2.EVENT_MOUSEMOVE: #redraw button everytime
                if (x >= UP_X and y >= UP_Y and x <= DOWN_X and y <= DOWN_Y):
                    self.button = True
                else:
                    self.button = False
                if self.drawing == True:
                    self.recDownX = x
                    self.recDownY = y
                                  
            elif event == cv2.EVENT_LBUTTONDOWN:
                if (x >= UP_X and y >= UP_Y and x <= DOWN_X and y <= DOWN_Y):
                    self.run = False
                    c()
                else:
                    self.drawing = True
                    self.recUpX = x
                    self.recUpY = y
                    self.recDownX = x
                    self.recDownY = y

            elif event == cv2.EVENT_LBUTTONUP:
                self.drawing = False
                    
        cv2.setMouseCallback('Runtime', event)

#####
        
class Settings:
    resolution = (0, 0)
    timelapse = False
    framerate = 0

#####

class Prototype:
    def __init__(self):
        self.c = Config()
        self.r = None
        self.c.saveOption(self.toRuntime)

    def toRuntime(self):
        self.settings = self.c.returnSettings()
        self.c.root.destroy()
        self.c = None
        self.r = Runtime(self.settings, self.toConfig)

    def toConfig(self):
        self.r = None
        self.c = Config()
        self.c.saveOption(self.toRuntime)
        
#####
    
p = Prototype()
        
